/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gameservice.guessthenumber.dao;

import com.gameservice.guessthenumber.DTO.Game;
import com.gameservice.guessthenumber.DTO.Round;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 *  
 */
@Repository
public class RoundDaoImpl implements RoundDao {

    @Autowired
    JdbcTemplate jdbc;

    private static final class GameMapper implements RowMapper<Round> {

        @Override
        public Round mapRow(ResultSet rs, int i) throws SQLException {
            Round g = new Round();
            g.setRoundID(rs.getInt("roundId"));
            g.setGameID(rs.getInt("gameId"));
            g.setGuess(rs.getString("guess"));
            g.setResult(rs.getString("result"));
            g.setTime(rs.getTimestamp("time").toLocalDateTime());
            return g;
        }

    }

    @Override
    public Round getARoundByID(int roundID) {
        try {
            Round gameRound = jdbc.queryForObject("SELECT * FROM game WHERE name = ?", new RoundDaoImpl.GameMapper(), roundID);
            return gameRound;
        } catch (DataAccessException ex) {
            return null;
        }
    }

    @Override
    public Round newRound(Round newRound) {
        jdbc.update("INSERT INTO Round(gameId, guess, result, time) VALUES(?,?,?,?)",
                newRound.getGameID(),
                newRound.getGuess(),
                newRound.getResult(),
                newRound.getTime());
        int newRoundID = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        newRound.setGameID(newRoundID);
        return newRound;
    }

    @Override
    public List<Round> getAllRounds() {
        List<Round> Round = jdbc.query("SELECT * FROM Round", new RoundDaoImpl.GameMapper());
        return Round;
    }

    @Override
    public void removeRounds(int roundID) {
        jdbc.update("DELETE FROM game WHERE name = ?", roundID);

    }

}
