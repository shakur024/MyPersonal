/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gameservice.guessthenumber.DTO;

/**
 *
 *
 */
public class Game {
// Here we set our instance variables for our game class.
   // Then we use our getters and setters method to extract the information.
    int gameID;
    String answer;
    String status;

    public Game(int gameID, String answer, String status) {
        this.gameID = gameID;
        this.answer = answer;
        this.status = status;
    }

    public Game(){
        
    }

    
    public int getGameID() {
        return gameID;
    }

    public void setGameID(int gameID) {
        this.gameID = gameID;
    }

    public String getAnswer() {
        return answer;
    }
    
    public void setAnswer(String answer){
        this.answer = answer;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
