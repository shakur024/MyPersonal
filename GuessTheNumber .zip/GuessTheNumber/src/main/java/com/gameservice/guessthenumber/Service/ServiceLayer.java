/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gameservice.guessthenumber.Service;

import com.gameservice.guessthenumber.DTO.Game;
import com.gameservice.guessthenumber.DTO.Round;
import java.util.List;

/**
 *

 */
public interface ServiceLayer {

    Game addGame();

    Game getGameByName(int gameID);

    List<Game> getAllGames();

    void removeGameID(int GameID);

    Round getARoundByID(int roundID);

    Round newRound(Round newRound);

    List<Round> getAllRounds();

    Round resultsOfRound(int gameId, String playerChoice);

    public void removeRounds(int roundID);

}
