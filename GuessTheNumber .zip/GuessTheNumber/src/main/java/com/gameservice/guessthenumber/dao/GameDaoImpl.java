/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gameservice.guessthenumber.dao;

import com.gameservice.guessthenumber.DTO.Game;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class GameDaoImpl implements GameDao {
//This is a Java code implementing the repository interface for a database table named "game".
    //The code uses the Spring Framework's JdbcTemplate class to interact with the database.
    
    @Autowired
    JdbcTemplate jdbc;
    //This line uses the @Autowired annotation to indicate that an instance of JdbcTemplate should be automatically created and injected into this variable by the Spring framework. 
    //JdbcTemplate is a utility class for simplifying JDBC database access in Spring applications.

    private static final class GameMapper implements RowMapper<Game> {

        @Override
        public Game mapRow(ResultSet rs, int i) throws SQLException {
            Game g = new Game();
            g.setGameID(rs.getInt("gameId"));
            g.setAnswer(rs.getString("answer"));
            g.setStatus(rs.getString("status"));
            return g;
        }

    }

    @Override
    public Game addGame(Game game) {
        // This method is used to add a new game to the "game" table in the database.
        //It uses the update method of the JdbcTemplate class to execute an SQL INSERT statement.
        
        jdbc.update("INSERT INTO game(gameId,answer, status) VALUES(?,?,?)",
                game.getGameID(),
                game.getAnswer(),
                game.getStatus());
        int newGameID = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        game.setGameID(newGameID);
        return game;
    }

    @Override
    public Game getGameByName(int gameID) {
        try {
            Game g = jdbc.queryForObject("SELECT * FROM game WHERE gameId = ?", new GameMapper(), gameID);
            return g;
        } catch (DataAccessException ex) {
            return null;
        }
    }
//This method retrieves a game from the "game" table in the database based on the game ID. 
    //It uses the queryForObject method of the JdbcTemplate class to execute an SQL SELECT statement and return the result as an instance of the Game class. 
    @Override
    public List<Game> getAllGames() {
        List<Game> games = jdbc.query("SELECT * FROM game", new GameMapper());
        return games;
    }

    @Override
    public void removeGameID(int gameID) {
        jdbc.update("DELETE FROM game WHERE gameId = ?", gameID);

    }

}
