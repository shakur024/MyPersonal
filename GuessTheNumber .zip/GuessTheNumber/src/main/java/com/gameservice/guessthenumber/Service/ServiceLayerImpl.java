/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gameservice.guessthenumber.Service;

import com.gameservice.guessthenumber.DTO.Game;
import com.gameservice.guessthenumber.DTO.Round;
import com.gameservice.guessthenumber.dao.GameDao;
import com.gameservice.guessthenumber.dao.GameDaoImpl;
import com.gameservice.guessthenumber.dao.RoundDaoImpl;
import java.util.List;
import java.util.Random;
import org.springframework.stereotype.Service;
import com.gameservice.guessthenumber.dao.RoundDao;
import java.util.HashSet;
import java.util.Set;

/**
 *
 */
@Service
public class ServiceLayerImpl implements ServiceLayer {

    GameDao gameDao = new GameDaoImpl();
    RoundDao roundDao = new RoundDaoImpl();

    public ServiceLayerImpl(GameDao dao, RoundDao round) {
        this.gameDao = dao;
        this.roundDao = round;
    }

    @Override
    public Game addGame() {
        Random rand = new Random();
        String choice = null;
        Set<Integer> uniqueNumbers = new HashSet<>();

        while (uniqueNumbers.size() < 4) {
            uniqueNumbers.add(rand.nextInt(10));
        }

        StringBuilder sb = new StringBuilder();
        for (int num : uniqueNumbers) {
            sb.append(num);
        }

        choice = sb.toString();
        Game g = new Game();
        g.setAnswer(choice);
        g.setStatus("in progress");
        gameDao.addGame(g);
        
        return g;
    }


    @Override
    public Game getGameByName(int gameId) {
        return gameDao.getGameByName(gameId);
    }

    @Override
    public List<Game> getAllGames() {
        return gameDao.getAllGames();
    }

    @Override
    public void removeGameID(int gameId) {
        gameDao.removeGameID(gameId);
    }

    @Override
    public Round getARoundByID(int roundId) {
        return roundDao.getARoundByID(roundId);
    }

    @Override
    public Round newRound(Round newRound) {
        return roundDao.newRound(newRound);
    }

    @Override
    public List<Round> getAllRounds() {
        return roundDao.getAllRounds();
    }

    @Override
    public Round resultsOfRound(int gameId, String playerChoice) {
        int match = 0;
        int partial = 0;

        Game g = gameDao.getGameByName(gameId);
        String answer = g.getAnswer();

        for (int i = 0; i < answer.length(); i++) {
            char randomChar = answer.charAt(i);
            char playerChar = playerChoice.charAt(i);
            if (randomChar == playerChar) {
                match++;
            } else if (answer.indexOf(playerChar) != -1) {
                partial++;
            }
        }

        final String DELIMITER = ":";
        String gameResult = "e" + DELIMITER + match + DELIMITER + "p" + DELIMITER + partial;
        Round round = new Round();
        round.setGameID(gameId);
        round.setRoundID(gameId);
        round.setGuess(playerChoice);
        round.setResult(gameResult);

        return roundDao.newRound(round);
    }

    @Override
    public void removeRounds(int roundId) {
        roundDao.removeRounds(roundId);
    }

}
