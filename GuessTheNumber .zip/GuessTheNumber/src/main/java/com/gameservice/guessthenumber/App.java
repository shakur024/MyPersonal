/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gameservice.guessthenumber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

 @SpringBootApplication
 //Here is in my spring boot annotation. 
public class App {
    public static void main(String[] args) {
        SpringApplication.run(App.class, args);
    }
}   

