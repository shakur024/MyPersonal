/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gameservice.guessthenumber.Service;

import com.gameservice.guessthenumber.DTO.Game;
import com.gameservice.guessthenumber.DTO.Round;
import com.gameservice.guessthenumber.dao.GameDao;
import com.gameservice.guessthenumber.dao.GameDaoImpl;
import com.gameservice.guessthenumber.dao.RoundDao;
import com.gameservice.guessthenumber.dao.RoundDaoImpl;
import java.util.List;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
/**
 *
 * @author 
 */
public class ServiceLayerImplTest  {
    
    
    private ServiceLayerImpl serviceLayer;
    private GameDao gameDao;
    private RoundDao roundDao;
    

    @Before
    public void setUp() throws Exception {
        gameDao = new GameDaoImpl();
        roundDao = new RoundDaoImpl();
        serviceLayer = new ServiceLayerImpl(gameDao, roundDao);
    }

    @Test
    public void addGameTest() {
        Game game = serviceLayer.addGame();
        assertNotNull(game);
        assertNotNull(game.getAnswer());
        assertEquals("in progress", game.getStatus());
    }

    @Test
    public void getGameByNameTest() {
        Game game = serviceLayer.addGame();
        int gameId = game.getGameID();
        Game retrievedGame = serviceLayer.getGameByName(gameId);
        assertNotNull(retrievedGame);
        assertEquals(game.getGameID(), retrievedGame.getGameID());
    }

    @Test
    public void getAllGamesTest() {
        Game game1 = serviceLayer.addGame();
        Game game2 = serviceLayer.addGame();
        List<Game> allGames = serviceLayer.getAllGames();
        assertNotNull(allGames);
        assertEquals(2, allGames.size());
    }

    @Test
    public void removeGameIDTest() {
        Game game = serviceLayer.addGame();
        int gameId = game.getGameID();
        serviceLayer.removeGameID(gameId);
        List<Game> allGames = serviceLayer.getAllGames();
        assertTrue(allGames.isEmpty());
    }

    @Test
    public void getARoundByIDTest() {
        Round round = new Round();
        round.setGameID(1);
        round.setRoundID(1);
        round.setGuess("1234");
        round.setResult("e:1:p:1");
        round = serviceLayer.newRound(round);
        int roundId = round.getRoundID();
        Round retrievedRound = serviceLayer.getARoundByID(roundId);
        assertNotNull(retrievedRound);
        assertEquals(round.getRoundID(), retrievedRound.getRoundID());
    }

    @Test
    public void newRoundTest() {
        Round round = new Round();
        round.setGameID(1);
        round.setRoundID(1);
        round.setGuess("1234");
        round.setResult("e:1:p:1");
        round = serviceLayer.newRound(round);
        assertNotNull(round);
        assertEquals(1, round.getGameID());
        assertEquals(1, round.getRoundID());
        assertEquals("1234", round.getGuess());
        assertEquals("e:1:p:1", round.getResult());
    }
}
