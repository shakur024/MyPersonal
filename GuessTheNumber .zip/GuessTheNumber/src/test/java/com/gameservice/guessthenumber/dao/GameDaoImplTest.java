/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gameservice.guessthenumber.dao;

import com.gameservice.guessthenumber.DTO.Game;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.MockitoAnnotations;


/**
 *
 *
 */
public class GameDaoImplTest {

    @Mock
    private GameDao gameDao;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testAddGame() {
        Game game = new Game();
        game.setGameID(1);
        game.setAnswer("Answer");
        game.setStatus("Active");

        when(gameDao.addGame(game)).thenReturn(game);

        Game result = gameDao.addGame(game);
        assertEquals(game, result);

        verify(gameDao, times(1)).addGame(game);
    }

    @Test
    public void testGetGameByName() {
        Game game = new Game();
        game.setGameID(1);
        game.setAnswer("Answer");
        game.setStatus("Active");

        when(gameDao.getGameByName(1)).thenReturn(game);

        Game result = gameDao.getGameByName(1);
        assertEquals(game, result);

        verify(gameDao, times(1)).getGameByName(1);
    }

  @Test
public void testGetAllGames() {
    List<Game> games = new ArrayList<>();
    Game game1 = new Game(1, "Answer 1", "Active");
    games.add(game1);
    Game game2 = new Game(2, "Answer 2", "Inactive");
    games.add(game2);

    when(gameDao.getAllGames()).thenReturn(games);

    List<Game> result = gameDao.getAllGames();

    verify(gameDao).getAllGames();
    assertEquals(games, result);
}

    @Test
    public void testRemoveGameID() {
        gameDao.removeGameID(1);
        verify(gameDao, times(1)).removeGameID(1);
    }

}
