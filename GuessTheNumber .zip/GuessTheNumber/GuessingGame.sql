drop database if exists GuessingGame;

create database GuessingGame;

use GuessingGame;

create table game(
gameID int primary key,
randomNumberGame varChar(50),
status int);

create table gameRound(
gameRoundID int primary key,
playerChoice VARCHAR(50),
`time` dateTime,
playerResult VARCHAR(50),
gameID int,
FOREIGN KEY (gameID) REFERENCES game(gameID));


