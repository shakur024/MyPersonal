/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gameservice.guessthenumber.dao;

import com.gameservice.guessthenumber.DTO.Round;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.junit.Assert;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.MockitoAnnotations;

/**
 *
 * @author magicman
 */
public class roundDaoImplTest {

    @Mock
    private RoundDao roundDao;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetARoundByID() {
        int roundID = 1;
        Round round = new Round();
        round.setRoundID(roundID);
        round.setGameID(1);
        round.setGuess("test");
        round.setResult("test");
        round.setTime(LocalDateTime.now());

        when(roundDao.getARoundByID(roundID)).thenReturn(round);

        Round result = roundDao.getARoundByID(roundID);

        verify(roundDao).getARoundByID(roundID);
        assertEquals(round, result);
    }

    @Test
    public void testNewRound() {
        Round newRound = new Round();
        newRound.setRoundID(1);
        newRound.setGameID(1);
        newRound.setGuess("test");
        newRound.setResult("test");
        newRound.setTime(LocalDateTime.now());

        when(roundDao.newRound(newRound)).thenReturn(newRound);

        Round result = roundDao.newRound(newRound);

        verify(roundDao).newRound(newRound);
        assertEquals(newRound, result);
    }

    @Test
    public void testGetAllRounds() {
        List<Round> rounds = new ArrayList<>();
        Round round1 = new Round();
        round1.setRoundID(1);
        round1.setGameID(1);
        round1.setGuess("test");
        round1.setResult("test");
        round1.setTime(LocalDateTime.now());
        rounds.add(round1);
        Round round2 = new Round();
        round2.setRoundID(2);
        round2.setGameID(2);
        round2.setGuess("test");
        round2.setResult("test");
        round2.setTime(LocalDateTime.now());
        rounds.add(round2);

        when(roundDao.getAllRounds()).thenReturn(rounds);

        List<Round> result = roundDao.getAllRounds();

        verify(roundDao).getAllRounds();
        assertEquals(rounds, result);
    }

    @Test
    public void testRemoveRounds() {
        int roundID = 1;

        doNothing().when(roundDao).removeRounds(roundID);

        roundDao.removeRounds(roundID);

        verify(roundDao).removeRounds(roundID);
    }
}
