/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gameservice.guessthenumber.dao;

import com.gameservice.guessthenumber.DTO.Round;
import java.util.List;

/**
 *
 * @author mohamed
 */
public interface RoundDao {

    Round getARoundByID(int roundID);

    Round newRound(Round newRound);

    List<Round> getAllRounds();

    public void removeRounds(int roundID);

}
