/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gameservice.guessthenumber.controller;

import com.gameservice.guessthenumber.DTO.Game;
import com.gameservice.guessthenumber.DTO.Round;
import com.gameservice.guessthenumber.Service.ServiceLayer;
import com.gameservice.guessthenumber.dao.GameDaoException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
// Here i request mapping to have on endpoints that hits /api 
public class controller {
//The endpoints are defined using Spring's @PostMapping and @GetMapping annotations, 
    //which map HTTP POST and GET requests to specific methods.
    @Autowired
    ServiceLayer service;
   //The ServiceLayer object, service, is being autowired and is used to call various methods of the game.

    @PostMapping("/NewGame")
    public Game newGame() throws GameDaoException {
        return service.addGame();
    }

    @GetMapping("/GetAllGames")
    public List<Game> getAllGames() throws GameDaoException {
        return service.getAllGames();
    }

    @GetMapping("game")
    public ResponseEntity<Game> getGame(@RequestParam("gameId") Integer gameID) throws GameDaoException {
        Game g = service.getGameByName(gameID);
        if (g == null) {
            return new ResponseEntity(null, HttpStatus.UNPROCESSABLE_ENTITY);
        }
        return ResponseEntity.ok(g);
    }

    @PostMapping("/NewGuess")
    public Round newGuess(@RequestParam("gameId")int gameID, @RequestParam("guess") String userInput) throws GameDaoException {
        return service.resultsOfRound(gameID, userInput);
    }

    @GetMapping("/GetAllRounds")
    public List<Round> getAllRounds() {
        return service.getAllRounds();
    }

}
