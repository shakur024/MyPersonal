/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gameservice.guessthenumber.dao;

import com.gameservice.guessthenumber.DTO.Game;
import java.util.List;

/**
 *
 * @author mohamed
 */
public interface GameDao {
    
    Game addGame(Game game);

    Game getGameByName(int gameID);

    List<Game> getAllGames();

    void removeGameID(int gameID);
}
